import { useState } from "react";
import DashboardHeader from "@/components/DashboardHeader";
import ProjectCard from "@/components/ProjectCard";
import StatsCard from "@/components/StatsCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search, FolderOpen, Users, DollarSign, Clock } from "lucide-react";

export default function Dashboard() {
  const [searchQuery, setSearchQuery] = useState("");

  // TODO: Remove mock data
  const mockProjects = [
    { id: '1', name: 'BPM 605', location: 'Somerset East', budget: 450000, status: 'Active' as const, activeLabourers: 24, supervisorCount: 2 },
    { id: '2', name: 'FDP 302', location: 'Port Elizabeth', budget: 680000, status: 'Active' as const, activeLabourers: 35, supervisorCount: 3 },
    { id: '3', name: 'TRN 158', location: 'East London', budget: 320000, status: 'On Hold' as const, activeLabourers: 0, supervisorCount: 1 },
    { id: '4', name: 'BPM 720', location: 'Grahamstown', budget: 550000, status: 'Completed' as const, activeLabourers: 0, supervisorCount: 2 },
  ];

  const filteredProjects = mockProjects.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (p.location && p.location.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader 
        userRole="Project Manager" 
        userName="Kholofelo Mooya" 
        notificationCount={3} 
      />
      
      <main className="px-6 md:px-12 py-8 space-y-8">
        {/* Overview Stats */}
        <div>
          <h2 className="text-2xl font-medium mb-6">Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatsCard title="Active Projects" value="2" icon={FolderOpen} description="2 on hold" />
            <StatsCard title="Total Labourers" value="59" icon={Users} description="Across all projects" />
            <StatsCard title="Pending Payments" value="R 125,450" icon={DollarSign} description="2 requests" />
            <StatsCard title="Next Payment Due" value="3 days" icon={Clock} description="Oct 31, 2025" />
          </div>
        </div>

        {/* Projects */}
        <div>
          <div className="flex items-center justify-between flex-wrap gap-4 mb-6">
            <h2 className="text-2xl font-medium">Projects</h2>
            <Button className="gap-2" data-testid="button-create-project">
              <Plus className="w-4 h-4" />
              Create Project
            </Button>
          </div>

          {/* Search */}
          <div className="relative mb-6 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search projects..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              data-testid="input-search-projects"
            />
          </div>

          {/* Project Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((project) => (
              <ProjectCard
                key={project.id}
                {...project}
                onClick={() => console.log('Project clicked:', project.id)}
              />
            ))}
          </div>

          {filteredProjects.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <Search className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No projects found</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
