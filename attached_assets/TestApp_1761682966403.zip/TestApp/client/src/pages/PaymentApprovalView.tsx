import DashboardHeader from "@/components/DashboardHeader";
import PaymentApproval from "@/components/PaymentApproval";

export default function PaymentApprovalView() {
  // TODO: Remove mock data
  const mockPayments = [
    { id: '1', name: 'John Dlamini', daysWorked: 14, totalMeters: 156.5, amount: 1956.25 },
    { id: '2', name: 'Sarah Nkosi', daysWorked: 12, totalMeters: 134.0, amount: 1675.00 },
    { id: '3', name: 'Michael Zulu', daysWorked: 14, totalMeters: 0, amount: 1400.00 },
    { id: '4', name: 'Thandi Mthembu', daysWorked: 10, totalMeters: 98.0, amount: 1225.00 },
    { id: '5', name: 'Peter Khumalo', daysWorked: 13, totalMeters: 145.5, amount: 1818.75 },
  ];

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader 
        userRole="Project Manager" 
        userName="Kholofelo Mooya" 
        notificationCount={3} 
      />
      
      <main className="px-6 md:px-12 py-8">
        <div className="max-w-7xl mx-auto">
          <PaymentApproval 
            period="1 - 14 October 2025"
            payments={mockPayments}
            status="Pending"
          />
        </div>
      </main>
    </div>
  );
}
