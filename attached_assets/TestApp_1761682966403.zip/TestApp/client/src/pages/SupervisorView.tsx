import { useState } from "react";
import DashboardHeader from "@/components/DashboardHeader";
import DailyWorkSheet from "@/components/DailyWorkSheet";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Plus, FileText } from "lucide-react";

export default function SupervisorView() {
  const [activeTab, setActiveTab] = useState("daily-work");

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  // TODO: Remove mock data
  const mockLabourers = [
    { id: '1', name: 'John Dlamini', employeeType: 'Civil Worker - Trenching', openRate: 12.50, closeRate: 8.00 },
    { id: '2', name: 'Sarah Nkosi', employeeType: 'Civil Worker - Trenching', openRate: 12.50, closeRate: 8.00 },
    { id: '3', name: 'Michael Zulu', employeeType: 'Flagman', openRate: 10.00, closeRate: 10.00 },
    { id: '4', name: 'Thandi Mthembu', employeeType: 'Civil Worker - Trenching', openRate: 12.50, closeRate: 8.00 },
  ];

  const mockPaymentPeriods = [
    { id: '1', period: '1 - 14 Oct 2025', status: 'Submitted' as const, amount: 25430.50 },
    { id: '2', period: '15 - 28 Oct 2025', status: 'Open' as const, amount: 18250.00 },
  ];

  const statusColors = {
    'Open': 'bg-blue-500',
    'Submitted': 'bg-amber-500',
    'Approved': 'bg-green-500',
  };

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader 
        userRole="Supervisor" 
        userName="Sipho Ndlovu" 
        notificationCount={1} 
      />
      
      <main className="px-6 md:px-12 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-medium mb-2">BPM 605 - Somerset East</h1>
          <p className="text-muted-foreground">Manage daily work and labourers</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="daily-work" data-testid="tab-daily-work">Daily Work</TabsTrigger>
            <TabsTrigger value="labourers" data-testid="tab-labourers">Labourers</TabsTrigger>
            <TabsTrigger value="payments" data-testid="tab-payments">Payments</TabsTrigger>
          </TabsList>

          <TabsContent value="daily-work" className="mt-6">
            <DailyWorkSheet 
              labourers={mockLabourers}
              date="Tuesday, 28 October 2025"
            />
          </TabsContent>

          <TabsContent value="labourers" className="mt-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0">
                <div>
                  <CardTitle>Project Labourers</CardTitle>
                  <CardDescription className="mt-2">Manage workers on this project</CardDescription>
                </div>
                <Button className="gap-2" data-testid="button-add-labourer">
                  <Plus className="w-4 h-4" />
                  Add Labourer
                </Button>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Employee Type</TableHead>
                      <TableHead>Contact</TableHead>
                      <TableHead className="w-24"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockLabourers.map((labourer) => (
                      <TableRow key={labourer.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar className="w-8 h-8">
                              <AvatarFallback className="text-xs">{getInitials(labourer.name)}</AvatarFallback>
                            </Avatar>
                            <span className="font-medium">{labourer.name}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-muted-foreground">{labourer.employeeType}</TableCell>
                        <TableCell className="text-muted-foreground font-mono text-sm">+27 82 123 4567</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm">View</Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="payments" className="mt-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0">
                <div>
                  <CardTitle>Payment Periods</CardTitle>
                  <CardDescription className="mt-2">Submit fortnightly payment requests</CardDescription>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Period</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="w-32"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockPaymentPeriods.map((period) => (
                      <TableRow key={period.id}>
                        <TableCell className="font-medium">{period.period}</TableCell>
                        <TableCell className="text-right font-mono">
                          R {period.amount.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
                        </TableCell>
                        <TableCell>
                          <Badge className={`${statusColors[period.status]} text-white`}>
                            {period.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {period.status === 'Open' ? (
                            <Button size="sm" variant="outline" className="gap-2">
                              <FileText className="w-4 h-4" />
                              Submit
                            </Button>
                          ) : (
                            <Button size="sm" variant="ghost">View</Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
