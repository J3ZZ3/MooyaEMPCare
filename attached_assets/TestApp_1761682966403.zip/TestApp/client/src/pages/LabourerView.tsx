import DashboardHeader from "@/components/DashboardHeader";
import LabourerDashboard from "@/components/LabourerDashboard";

export default function LabourerView() {
  // TODO: Remove mock data
  const mockWorkRecords = [
    { id: '1', date: 'Oct 15, 2025', openMeters: 12.5, closeMeters: 8.0, earnings: 220.00, status: 'Approved' as const },
    { id: '2', date: 'Oct 16, 2025', openMeters: 11.0, closeMeters: 9.5, earnings: 213.50, status: 'Approved' as const },
    { id: '3', date: 'Oct 17, 2025', openMeters: 13.5, closeMeters: 7.5, earnings: 228.75, status: 'Approved' as const },
    { id: '4', date: 'Oct 18, 2025', openMeters: 10.0, closeMeters: 10.0, earnings: 205.00, status: 'Approved' as const },
    { id: '5', date: 'Oct 21, 2025', openMeters: 14.0, closeMeters: 6.5, earnings: 227.00, status: 'Approved' as const },
    { id: '6', date: 'Oct 22, 2025', openMeters: 12.0, closeMeters: 8.5, earnings: 218.00, status: 'Approved' as const },
    { id: '7', date: 'Oct 23, 2025', openMeters: 11.5, closeMeters: 9.0, earnings: 215.75, status: 'Pending' as const },
    { id: '8', date: 'Oct 24, 2025', openMeters: 13.0, closeMeters: 7.0, earnings: 218.50, status: 'Pending' as const },
  ];

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader 
        userRole="Local Labourer" 
        userName="John Dlamini" 
        notificationCount={2} 
      />
      
      <main className="px-6 md:px-12 py-8">
        <LabourerDashboard 
          labourerName="John Dlamini"
          workRecords={mockWorkRecords}
        />
      </main>
    </div>
  );
}
