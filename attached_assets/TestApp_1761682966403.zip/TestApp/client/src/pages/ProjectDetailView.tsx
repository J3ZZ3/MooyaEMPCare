import DashboardHeader from "@/components/DashboardHeader";
import ProjectDashboard from "@/components/ProjectDashboard";

export default function ProjectDetailView() {
  // TODO: Remove mock data
  const mockProject = {
    name: 'BPM 605',
    location: 'Somerset East',
    budget: 450000,
    status: 'Active'
  };

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader 
        userRole="Project Manager" 
        userName="Kholofelo Mooya" 
        notificationCount={3} 
      />
      
      <main className="px-6 md:px-12 py-8">
        <ProjectDashboard project={mockProject} />
      </main>
    </div>
  );
}
