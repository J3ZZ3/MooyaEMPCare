import DashboardHeader from "@/components/DashboardHeader";
import LabourerForm from "@/components/LabourerForm";

export default function LabourerOnboardingView() {
  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader 
        userRole="Supervisor" 
        userName="Sipho Ndlovu" 
        notificationCount={1} 
      />
      
      <main className="px-6 md:px-12 py-8">
        <LabourerForm />
      </main>
    </div>
  );
}
