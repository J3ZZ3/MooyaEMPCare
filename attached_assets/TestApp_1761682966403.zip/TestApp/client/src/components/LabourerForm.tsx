import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Upload, User } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function LabourerForm() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    firstName: '',
    surname: '',
    idNumber: '',
    dateOfBirth: '',
    contactNumber: '',
    employeeType: '',
    bankName: '',
    accountNumber: '',
    accountType: '',
    branchCode: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    toast({
      title: "Labourer added successfully",
      description: "The worker profile has been created.",
    });
  };

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl">Add New Labourer</CardTitle>
        <CardDescription>Complete the worker profile information</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Profile Photo */}
          <div className="flex items-center gap-6">
            <Avatar className="w-24 h-24">
              <AvatarFallback>
                <User className="w-12 h-12" />
              </AvatarFallback>
            </Avatar>
            <div>
              <Label>Profile Photo *</Label>
              <Button variant="outline" className="mt-2 gap-2" type="button" data-testid="button-upload-photo">
                <Upload className="w-4 h-4" />
                Upload Photo
              </Button>
              <p className="text-xs text-muted-foreground mt-1">JPG or PNG, max 5MB</p>
            </div>
          </div>

          {/* Personal Information */}
          <div>
            <h3 className="text-lg font-medium mb-4">Personal Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name *</Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
                  data-testid="input-first-name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="surname">Surname *</Label>
                <Input
                  id="surname"
                  value={formData.surname}
                  onChange={(e) => setFormData(prev => ({ ...prev, surname: e.target.value }))}
                  data-testid="input-surname"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="idNumber">ID / Passport Number *</Label>
                <Input
                  id="idNumber"
                  placeholder="13 digits for SA ID"
                  value={formData.idNumber}
                  onChange={(e) => setFormData(prev => ({ ...prev, idNumber: e.target.value }))}
                  data-testid="input-id-number"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dateOfBirth">Date of Birth *</Label>
                <Input
                  id="dateOfBirth"
                  type="date"
                  value={formData.dateOfBirth}
                  onChange={(e) => setFormData(prev => ({ ...prev, dateOfBirth: e.target.value }))}
                  data-testid="input-date-of-birth"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="contactNumber">Contact Number *</Label>
                <Input
                  id="contactNumber"
                  placeholder="+27 or 0"
                  value={formData.contactNumber}
                  onChange={(e) => setFormData(prev => ({ ...prev, contactNumber: e.target.value }))}
                  data-testid="input-contact-number"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="employeeType">Employee Type *</Label>
                <Select value={formData.employeeType} onValueChange={(value) => setFormData(prev => ({ ...prev, employeeType: value }))}>
                  <SelectTrigger id="employeeType" data-testid="select-employee-type">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="civil-trenching">Civil Worker - Trenching</SelectItem>
                    <SelectItem value="flagman">Flagman</SelectItem>
                    <SelectItem value="general">General Labourer</SelectItem>
                    <SelectItem value="equipment">Equipment Operator</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Banking Details */}
          <div>
            <h3 className="text-lg font-medium mb-4">Banking Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="bankName">Bank Name *</Label>
                <Select value={formData.bankName} onValueChange={(value) => setFormData(prev => ({ ...prev, bankName: value }))}>
                  <SelectTrigger id="bankName" data-testid="select-bank-name">
                    <SelectValue placeholder="Select bank" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="absa">ABSA</SelectItem>
                    <SelectItem value="fnb">FNB</SelectItem>
                    <SelectItem value="standard">Standard Bank</SelectItem>
                    <SelectItem value="nedbank">Nedbank</SelectItem>
                    <SelectItem value="capitec">Capitec</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="accountNumber">Account Number *</Label>
                <Input
                  id="accountNumber"
                  value={formData.accountNumber}
                  onChange={(e) => setFormData(prev => ({ ...prev, accountNumber: e.target.value }))}
                  data-testid="input-account-number"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="accountType">Account Type *</Label>
                <Select value={formData.accountType} onValueChange={(value) => setFormData(prev => ({ ...prev, accountType: value }))}>
                  <SelectTrigger id="accountType" data-testid="select-account-type">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cheque">Cheque</SelectItem>
                    <SelectItem value="savings">Savings</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="branchCode">Branch Code *</Label>
                <Input
                  id="branchCode"
                  value={formData.branchCode}
                  onChange={(e) => setFormData(prev => ({ ...prev, branchCode: e.target.value }))}
                  data-testid="input-branch-code"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-4">
            <Button variant="outline" type="button" data-testid="button-cancel">
              Cancel
            </Button>
            <Button type="submit" data-testid="button-save-labourer">
              Save Labourer
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
