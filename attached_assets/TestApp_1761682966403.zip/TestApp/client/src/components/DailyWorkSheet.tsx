import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Calendar } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Labourer {
  id: string;
  name: string;
  employeeType: string;
  openRate: number;
  closeRate: number;
}

interface WorkEntry {
  labourerId: string;
  openMeters: number;
  closeMeters: number;
}

interface DailyWorkSheetProps {
  labourers: Labourer[];
  date: string;
}

export default function DailyWorkSheet({ labourers, date }: DailyWorkSheetProps) {
  const { toast } = useToast();
  const [workEntries, setWorkEntries] = useState<Record<string, WorkEntry>>(
    labourers.reduce((acc, l) => ({
      ...acc,
      [l.id]: { labourerId: l.id, openMeters: 0, closeMeters: 0 }
    }), {})
  );

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  const calculateDailyEarnings = (labourerId: string) => {
    const entry = workEntries[labourerId];
    const labourer = labourers.find(l => l.id === labourerId);
    if (!entry || !labourer) return 0;
    return (entry.openMeters * labourer.openRate) + (entry.closeMeters * labourer.closeRate);
  };

  const updateMeters = (labourerId: string, field: 'openMeters' | 'closeMeters', value: string) => {
    const numValue = parseFloat(value) || 0;
    setWorkEntries(prev => ({
      ...prev,
      [labourerId]: {
        ...prev[labourerId],
        [field]: numValue
      }
    }));
  };

  const handleSubmit = () => {
    console.log('Submitting daily work sheet:', workEntries);
    toast({
      title: "Work sheet submitted",
      description: "Daily work has been recorded and labourers notified.",
    });
  };

  const getTotalMeters = (field: 'openMeters' | 'closeMeters') => {
    return Object.values(workEntries).reduce((sum, entry) => sum + entry[field], 0);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <CardTitle className="text-2xl">Daily Work Sheet</CardTitle>
            <CardDescription className="flex items-center gap-2 mt-2">
              <Calendar className="w-4 h-4" />
              {date}
            </CardDescription>
          </div>
          <Button onClick={handleSubmit} data-testid="button-submit-work">
            Submit Daily Work
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Labourer</TableHead>
                <TableHead>Type</TableHead>
                <TableHead className="text-right">Open Meters</TableHead>
                <TableHead className="text-right">Close Meters</TableHead>
                <TableHead className="text-right">Daily Earnings</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {labourers.map((labourer) => (
                <TableRow key={labourer.id} data-testid={`row-labourer-${labourer.id}`}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="text-xs">{getInitials(labourer.name)}</AvatarFallback>
                      </Avatar>
                      <span className="font-medium">{labourer.name}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {labourer.employeeType}
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="0.00"
                      className="w-24 text-right font-mono"
                      value={workEntries[labourer.id].openMeters || ''}
                      onChange={(e) => updateMeters(labourer.id, 'openMeters', e.target.value)}
                      data-testid={`input-open-meters-${labourer.id}`}
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="0.00"
                      className="w-24 text-right font-mono"
                      value={workEntries[labourer.id].closeMeters || ''}
                      onChange={(e) => updateMeters(labourer.id, 'closeMeters', e.target.value)}
                      data-testid={`input-close-meters-${labourer.id}`}
                    />
                  </TableCell>
                  <TableCell className="text-right font-mono font-medium" data-testid={`text-earnings-${labourer.id}`}>
                    R {calculateDailyEarnings(labourer.id).toFixed(2)}
                  </TableCell>
                </TableRow>
              ))}
              <TableRow className="bg-muted/50 font-medium">
                <TableCell colSpan={2}>Total</TableCell>
                <TableCell className="text-right font-mono">{getTotalMeters('openMeters').toFixed(2)}m</TableCell>
                <TableCell className="text-right font-mono">{getTotalMeters('closeMeters').toFixed(2)}m</TableCell>
                <TableCell className="text-right font-mono">
                  R {labourers.reduce((sum, l) => sum + calculateDailyEarnings(l.id), 0).toFixed(2)}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
