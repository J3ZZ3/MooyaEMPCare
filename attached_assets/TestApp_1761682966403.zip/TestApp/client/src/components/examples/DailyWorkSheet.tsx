import DailyWorkSheet from '../DailyWorkSheet';

export default function DailyWorkSheetExample() {
  // TODO: Remove mock data
  const mockLabourers = [
    { id: '1', name: 'John Dlamini', employeeType: 'Civil Worker - Trenching', openRate: 12.50, closeRate: 8.00 },
    { id: '2', name: 'Sarah Nkosi', employeeType: 'Civil Worker - Trenching', openRate: 12.50, closeRate: 8.00 },
    { id: '3', name: 'Michael Zulu', employeeType: 'Flagman', openRate: 10.00, closeRate: 10.00 },
  ];

  return (
    <div className="p-6">
      <DailyWorkSheet 
        labourers={mockLabourers}
        date="Tuesday, 28 October 2025"
      />
    </div>
  );
}
