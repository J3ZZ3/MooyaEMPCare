import LabourerForm from '../LabourerForm';

export default function LabourerFormExample() {
  return (
    <div className="p-6">
      <LabourerForm />
    </div>
  );
}
