import LoginPage from '../LoginPage';

export default function LoginPageExample() {
  return <LoginPage />;
}
