import LabourerDashboard from '../LabourerDashboard';

export default function LabourerDashboardExample() {
  // TODO: Remove mock data
  const mockWorkRecords = [
    { id: '1', date: 'Oct 15, 2025', openMeters: 12.5, closeMeters: 8.0, earnings: 220.00, status: 'Approved' as const },
    { id: '2', date: 'Oct 16, 2025', openMeters: 11.0, closeMeters: 9.5, earnings: 213.50, status: 'Approved' as const },
    { id: '3', date: 'Oct 17, 2025', openMeters: 13.5, closeMeters: 7.5, earnings: 228.75, status: 'Approved' as const },
    { id: '4', date: 'Oct 18, 2025', openMeters: 10.0, closeMeters: 10.0, earnings: 205.00, status: 'Pending' as const },
  ];

  return (
    <div className="p-6">
      <LabourerDashboard 
        labourerName="John Dlamini"
        workRecords={mockWorkRecords}
      />
    </div>
  );
}
