import ProjectDashboard from '../ProjectDashboard';

export default function ProjectDashboardExample() {
  // TODO: Remove mock data
  const mockProject = {
    name: 'BPM 605',
    location: 'Somerset East',
    budget: 450000,
    status: 'Active'
  };

  return (
    <div className="p-6">
      <ProjectDashboard project={mockProject} />
    </div>
  );
}
