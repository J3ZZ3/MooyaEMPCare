import PaymentApproval from '../PaymentApproval';

export default function PaymentApprovalExample() {
  // TODO: Remove mock data
  const mockPayments = [
    { id: '1', name: 'John Dlamini', daysWorked: 14, totalMeters: 156.5, amount: 1956.25 },
    { id: '2', name: 'Sarah Nkosi', daysWorked: 12, totalMeters: 134.0, amount: 1675.00 },
    { id: '3', name: 'Michael Zulu', daysWorked: 14, totalMeters: 0, amount: 1400.00 },
    { id: '4', name: 'Thandi Mthembu', daysWorked: 10, totalMeters: 98.0, amount: 1225.00 },
  ];

  return (
    <div className="p-6">
      <PaymentApproval 
        period="1 - 14 October 2025"
        payments={mockPayments}
        status="Pending"
      />
    </div>
  );
}
