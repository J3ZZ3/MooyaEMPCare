import DashboardHeader from '../DashboardHeader';

export default function DashboardHeaderExample() {
  return <DashboardHeader userRole="Project Manager" userName="Kholofelo Mooya" notificationCount={3} />;
}
