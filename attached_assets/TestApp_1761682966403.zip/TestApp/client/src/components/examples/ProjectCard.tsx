import ProjectCard from '../ProjectCard';

export default function ProjectCardExample() {
  return (
    <div className="p-6 max-w-md">
      <ProjectCard
        id="1"
        name="BPM 605"
        location="Somerset East"
        budget={450000}
        status="Active"
        activeLabourers={24}
        supervisorCount={2}
        onClick={() => console.log('Project clicked')}
      />
    </div>
  );
}
