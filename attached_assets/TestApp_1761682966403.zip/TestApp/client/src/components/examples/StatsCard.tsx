import StatsCard from '../StatsCard';
import { DollarSign } from 'lucide-react';

export default function StatsCardExample() {
  return (
    <div className="p-6 max-w-sm">
      <StatsCard
        title="Current Period Earnings"
        value="R 3,240"
        icon={DollarSign}
        description="14 days worked"
      />
    </div>
  );
}
