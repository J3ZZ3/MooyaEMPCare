import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Download, Check, X, Calendar } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface LabourerPayment {
  id: string;
  name: string;
  daysWorked: number;
  totalMeters: number;
  amount: number;
}

interface PaymentApprovalProps {
  period: string;
  payments: LabourerPayment[];
  status: 'Pending' | 'Approved' | 'Rejected';
}

export default function PaymentApproval({ period, payments, status }: PaymentApprovalProps) {
  const { toast } = useToast();
  
  const totalAmount = payments.reduce((sum, p) => sum + p.amount, 0);

  const handleApprove = () => {
    console.log('Payment approved');
    toast({
      title: "Payment approved",
      description: "CSV file generated and ready for download.",
    });
  };

  const handleReject = () => {
    console.log('Payment rejected');
    toast({
      title: "Payment rejected",
      description: "Supervisor has been notified.",
      variant: "destructive",
    });
  };

  const handleDownload = () => {
    console.log('Downloading CSV');
    toast({
      title: "Downloading payment file",
      description: "Banking CSV file is being prepared.",
    });
  };

  const statusColors = {
    'Pending': 'bg-amber-500',
    'Approved': 'bg-green-500',
    'Rejected': 'bg-red-500'
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <CardTitle className="text-2xl">Payment Approval</CardTitle>
            <CardDescription className="flex items-center gap-2 mt-2">
              <Calendar className="w-4 h-4" />
              {period}
            </CardDescription>
          </div>
          <Badge className={`${statusColors[status]} text-white`} data-testid="badge-payment-status">
            {status}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-muted rounded-md">
          <div>
            <p className="text-sm text-muted-foreground">Total Labourers</p>
            <p className="text-2xl font-medium font-mono">{payments.length}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Total Days Worked</p>
            <p className="text-2xl font-medium font-mono">
              {payments.reduce((sum, p) => sum + p.daysWorked, 0)}
            </p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Total Amount</p>
            <p className="text-2xl font-medium font-mono" data-testid="text-total-amount">
              R {totalAmount.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
            </p>
          </div>
        </div>

        {/* Payment Breakdown */}
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Labourer</TableHead>
                <TableHead className="text-right">Days Worked</TableHead>
                <TableHead className="text-right">Total Meters</TableHead>
                <TableHead className="text-right">Amount</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {payments.map((payment) => (
                <TableRow key={payment.id} data-testid={`row-payment-${payment.id}`}>
                  <TableCell className="font-medium">{payment.name}</TableCell>
                  <TableCell className="text-right font-mono">{payment.daysWorked}</TableCell>
                  <TableCell className="text-right font-mono">{payment.totalMeters.toFixed(2)}m</TableCell>
                  <TableCell className="text-right font-mono font-medium">
                    R {payment.amount.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-4 pt-4 border-t">
          {status === 'Approved' ? (
            <Button onClick={handleDownload} className="gap-2" data-testid="button-download-csv">
              <Download className="w-4 h-4" />
              Download CSV
            </Button>
          ) : status === 'Pending' ? (
            <>
              <Button variant="outline" onClick={handleReject} className="gap-2" data-testid="button-reject">
                <X className="w-4 h-4" />
                Reject
              </Button>
              <Button onClick={handleApprove} className="gap-2" data-testid="button-approve">
                <Check className="w-4 h-4" />
                Approve Payment
              </Button>
            </>
          ) : null}
        </div>
      </CardContent>
    </Card>
  );
}
