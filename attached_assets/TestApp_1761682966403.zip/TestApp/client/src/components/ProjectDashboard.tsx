import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MapPin, TrendingUp, Users, Plus, Settings } from "lucide-react";
import StatsCard from "./StatsCard";

interface ProjectDashboardProps {
  project: {
    name: string;
    location: string;
    budget: number;
    status: string;
  };
}

export default function ProjectDashboard({ project }: ProjectDashboardProps) {
  const [activeTab, setActiveTab] = useState("overview");

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  // TODO: Remove mock data
  const mockTeam = [
    { id: '1', name: 'Kholofelo Mooya', role: 'Project Manager', email: 'kholofelo@mooya.co.za' },
    { id: '2', name: 'Sipho Ndlovu', role: 'Supervisor', email: 'sipho@mooya.co.za' },
  ];

  const mockRates = [
    { id: '1', employeeType: 'Civil Worker - Trenching', openRate: 12.50, closeRate: 8.00, effectiveDate: '2025-10-01' },
    { id: '2', employeeType: 'Flagman', openRate: 10.00, closeRate: 10.00, effectiveDate: '2025-10-01' },
  ];

  return (
    <div className="space-y-6">
      {/* Project Header */}
      <div>
        <div className="flex items-start justify-between flex-wrap gap-4 mb-4">
          <div>
            <h1 className="text-3xl font-medium mb-2">{project.name}</h1>
            <div className="flex items-center gap-4 text-muted-foreground">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                <span>{project.location}</span>
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                <span className="font-mono">R {project.budget.toLocaleString()}</span>
              </div>
            </div>
          </div>
          <Badge className="bg-green-500 text-white">{project.status}</Badge>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard title="Active Labourers" value="24" icon={Users} />
          <StatsCard title="Current Period" value="R 45,230" icon={TrendingUp} description="14 days" />
          <StatsCard title="Total Meters" value="1,245.5" icon={Settings} description="This period" />
          <StatsCard title="Days Remaining" value="7" icon={Settings} description="Until payment" />
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
          <TabsTrigger value="team" data-testid="tab-team">Team</TabsTrigger>
          <TabsTrigger value="rates" data-testid="tab-rates">Pay Rates</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Project Overview</CardTitle>
              <CardDescription>Key project information and statistics</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Project dashboard showing real-time statistics and current period information.
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="team" className="space-y-4 mt-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0">
              <div>
                <CardTitle>Team Members</CardTitle>
                <CardDescription className="mt-2">Project managers and supervisors</CardDescription>
              </div>
              <Button className="gap-2" data-testid="button-add-team-member">
                <Plus className="w-4 h-4" />
                Add Member
              </Button>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead className="w-24"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockTeam.map((member) => (
                    <TableRow key={member.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="w-8 h-8">
                            <AvatarFallback className="text-xs">{getInitials(member.name)}</AvatarFallback>
                          </Avatar>
                          <span className="font-medium">{member.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{member.role}</Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{member.email}</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">Remove</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rates" className="space-y-4 mt-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0">
              <div>
                <CardTitle>Pay Rates</CardTitle>
                <CardDescription className="mt-2">Configure compensation rates per employee type</CardDescription>
              </div>
              <Button className="gap-2" data-testid="button-add-rate">
                <Plus className="w-4 h-4" />
                Add Rate
              </Button>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee Type</TableHead>
                    <TableHead className="text-right">Open Trenching</TableHead>
                    <TableHead className="text-right">Close Trenching</TableHead>
                    <TableHead>Effective Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockRates.map((rate) => (
                    <TableRow key={rate.id}>
                      <TableCell className="font-medium">{rate.employeeType}</TableCell>
                      <TableCell className="text-right font-mono">R {rate.openRate.toFixed(2)}/m</TableCell>
                      <TableCell className="text-right font-mono">R {rate.closeRate.toFixed(2)}/m</TableCell>
                      <TableCell className="text-muted-foreground">{rate.effectiveDate}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
