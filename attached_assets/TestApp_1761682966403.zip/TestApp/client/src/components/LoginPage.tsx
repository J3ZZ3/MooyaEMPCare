import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FcGoogle } from "react-icons/fc";

export default function LoginPage() {
  const handleGoogleLogin = () => {
    console.log('Google login triggered');
    // TODO: Implement Google OAuth with domain restriction
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-6">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-4 text-center">
          <div className="mx-auto w-16 h-16 bg-primary rounded-md flex items-center justify-center">
            <span className="text-2xl font-bold text-primary-foreground">MW</span>
          </div>
          <CardTitle className="text-2xl">Fibre Deployment Management</CardTitle>
          <CardDescription>
            Mooya Wireless workforce and payroll system
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <Button
            onClick={handleGoogleLogin}
            variant="outline"
            size="lg"
            className="w-full gap-3"
            data-testid="button-google-login"
          >
            <FcGoogle className="w-5 h-5" />
            Sign in with Google
          </Button>
          <p className="text-sm text-muted-foreground text-center">
            Restricted to @mooya.co.za and @mooyawireless.co.za email addresses
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
