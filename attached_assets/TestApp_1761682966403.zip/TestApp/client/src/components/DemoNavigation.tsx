import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { Users, Briefcase, HardHat, FileText, DollarSign, UserPlus } from "lucide-react";

export default function DemoNavigation() {
  const [, setLocation] = useLocation();

  const demoViews = [
    {
      title: "Project Manager Dashboard",
      description: "View and manage all projects, approve payments",
      icon: Briefcase,
      path: "/dashboard",
      color: "bg-blue-500"
    },
    {
      title: "Supervisor View",
      description: "Record daily work, manage labourers, submit payments",
      icon: HardHat,
      path: "/supervisor",
      color: "bg-green-500"
    },
    {
      title: "Labourer Dashboard",
      description: "View personal work history and payment status",
      icon: Users,
      path: "/labourer",
      color: "bg-purple-500"
    },
    {
      title: "Project Details",
      description: "Detailed project view with team and pay rates",
      icon: FileText,
      path: "/project/1",
      color: "bg-amber-500"
    },
    {
      title: "Payment Approval",
      description: "Review and approve fortnightly payment requests",
      icon: DollarSign,
      path: "/payments/1",
      color: "bg-red-500"
    },
    {
      title: "Labourer Onboarding",
      description: "Add new workers with complete profile information",
      icon: UserPlus,
      path: "/onboarding",
      color: "bg-teal-500"
    }
  ];

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-6">
      <div className="w-full max-w-6xl">
        <Card className="mb-8">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-primary rounded-md flex items-center justify-center mb-4">
              <span className="text-2xl font-bold text-primary-foreground">MW</span>
            </div>
            <CardTitle className="text-3xl">Fibre Deployment Management</CardTitle>
            <CardDescription className="text-base mt-2">
              Mooya Wireless - Interactive Prototype Demo
            </CardDescription>
          </CardHeader>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {demoViews.map((view) => (
            <Card 
              key={view.path} 
              className="hover-elevate cursor-pointer transition-shadow"
              onClick={() => setLocation(view.path)}
              data-testid={`card-demo-${view.path}`}
            >
              <CardHeader>
                <div className={`w-12 h-12 ${view.color} rounded-md flex items-center justify-center mb-3`}>
                  <view.icon className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-xl">{view.title}</CardTitle>
                <CardDescription className="mt-2">{view.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={(e) => {
                    e.stopPropagation();
                    setLocation(view.path);
                  }}
                >
                  View Demo
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="mt-8">
          <CardContent className="p-6 text-center text-sm text-muted-foreground">
            <p>This is a high-fidelity prototype demonstrating the key features and user interfaces.</p>
            <p className="mt-2">Click any card above to explore different user role perspectives.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
