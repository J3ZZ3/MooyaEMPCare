import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Users, TrendingUp } from "lucide-react";

interface ProjectCardProps {
  id: string;
  name: string;
  location?: string;
  budget?: number;
  status: 'Active' | 'Completed' | 'On Hold';
  activeLabourers: number;
  supervisorCount: number;
  onClick?: () => void;
}

export default function ProjectCard({
  name,
  location,
  budget,
  status,
  activeLabourers,
  supervisorCount,
  onClick
}: ProjectCardProps) {
  const statusColors = {
    'Active': 'bg-green-500',
    'Completed': 'bg-gray-500',
    'On Hold': 'bg-amber-500'
  };

  return (
    <Card 
      className="hover-elevate cursor-pointer transition-shadow"
      onClick={onClick}
      data-testid="card-project"
    >
      <CardHeader className="flex flex-row items-start justify-between gap-2 space-y-0 pb-4">
        <CardTitle className="text-xl font-medium">{name}</CardTitle>
        <Badge 
          className={`${statusColors[status]} text-white`}
          data-testid="badge-project-status"
        >
          {status}
        </Badge>
      </CardHeader>
      <CardContent className="space-y-3">
        {location && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="w-4 h-4" />
            <span>{location}</span>
          </div>
        )}
        {budget && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <TrendingUp className="w-4 h-4" />
            <span className="font-mono">R {budget.toLocaleString()}</span>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between gap-4 pt-4 border-t">
        <div className="flex items-center gap-2 text-sm">
          <Users className="w-4 h-4 text-muted-foreground" />
          <span className="font-mono" data-testid="text-active-labourers">{activeLabourers}</span>
          <span className="text-muted-foreground">labourers</span>
        </div>
        <div className="text-sm text-muted-foreground">
          <span className="font-mono">{supervisorCount}</span> supervisor{supervisorCount !== 1 ? 's' : ''}
        </div>
      </CardFooter>
    </Card>
  );
}
