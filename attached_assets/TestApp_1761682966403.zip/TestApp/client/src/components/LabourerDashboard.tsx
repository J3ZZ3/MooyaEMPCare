import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Calendar, DollarSign, Ruler, Clock } from "lucide-react";
import StatsCard from "./StatsCard";

interface WorkRecord {
  id: string;
  date: string;
  openMeters: number;
  closeMeters: number;
  earnings: number;
  status: 'Pending' | 'Approved' | 'Paid';
}

interface LabourerDashboardProps {
  labourerName: string;
  workRecords: WorkRecord[];
}

export default function LabourerDashboard({ labourerName, workRecords }: LabourerDashboardProps) {
  const currentPeriodEarnings = workRecords.reduce((sum, r) => sum + r.earnings, 0);
  const daysWorked = workRecords.length;
  const totalMeters = workRecords.reduce((sum, r) => sum + r.openMeters + r.closeMeters, 0);

  const statusColors = {
    'Pending': 'bg-amber-500',
    'Approved': 'bg-green-500',
    'Paid': 'bg-blue-500'
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-medium mb-2">Welcome, {labourerName}</h1>
        <p className="text-muted-foreground">View your work history and payment status</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard 
          title="Current Period Earnings" 
          value={`R ${currentPeriodEarnings.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}`}
          icon={DollarSign}
          description={`${daysWorked} days worked`}
        />
        <StatsCard 
          title="Total Meters" 
          value={totalMeters.toFixed(1)}
          icon={Ruler}
          description="This period"
        />
        <StatsCard 
          title="Next Payment" 
          value="7 days"
          icon={Clock}
          description="Oct 31, 2025"
        />
        <StatsCard 
          title="Days Worked" 
          value={daysWorked}
          icon={Calendar}
          description="Current period"
        />
      </div>

      {/* Work History */}
      <Card>
        <CardHeader>
          <CardTitle>Work History</CardTitle>
          <CardDescription>Your daily work records for the current period</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Open Meters</TableHead>
                  <TableHead className="text-right">Close Meters</TableHead>
                  <TableHead className="text-right">Earnings</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {workRecords.map((record) => (
                  <TableRow key={record.id} data-testid={`row-work-record-${record.id}`}>
                    <TableCell className="font-medium">{record.date}</TableCell>
                    <TableCell className="text-right font-mono">{record.openMeters.toFixed(2)}m</TableCell>
                    <TableCell className="text-right font-mono">{record.closeMeters.toFixed(2)}m</TableCell>
                    <TableCell className="text-right font-mono font-medium">
                      R {record.earnings.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
                    </TableCell>
                    <TableCell>
                      <Badge className={`${statusColors[record.status]} text-white`}>
                        {record.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
                <TableRow className="bg-muted/50 font-medium">
                  <TableCell>Total</TableCell>
                  <TableCell className="text-right font-mono">
                    {workRecords.reduce((sum, r) => sum + r.openMeters, 0).toFixed(2)}m
                  </TableCell>
                  <TableCell className="text-right font-mono">
                    {workRecords.reduce((sum, r) => sum + r.closeMeters, 0).toFixed(2)}m
                  </TableCell>
                  <TableCell className="text-right font-mono">
                    R {currentPeriodEarnings.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
                  </TableCell>
                  <TableCell></TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
