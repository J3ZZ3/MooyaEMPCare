import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, timestamp, integer, boolean, pgEnum, uuid, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const userRoleEnum = pgEnum('user_role', ['super_admin', 'admin', 'project_manager', 'supervisor', 'project_administrator', 'user']);
export const projectStatusEnum = pgEnum('project_status', ['active', 'completed', 'on_hold']);
export const accountTypeEnum = pgEnum('account_type', ['cheque', 'savings']);
export const paymentStatusEnum = pgEnum('payment_status', ['open', 'submitted', 'approved', 'rejected', 'paid']);
export const rateCategoryEnum = pgEnum('rate_category', ['open_trenching', 'close_trenching', 'custom']);
export const rateUnitEnum = pgEnum('rate_unit', ['per_meter', 'per_day', 'fixed']);
export const correctionStatusEnum = pgEnum('correction_status', ['pending', 'approved', 'rejected']);

// Session storage table for Replit Auth (REQUIRED)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Users table - adapted for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`), // Replit Auth uses varchar for ID
  email: varchar("email").unique(), // Replit Auth fields
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: userRoleEnum("role").notNull().default('user'), // Custom field for RBAC
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Projects table
export const projects = pgTable("projects", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 255 }).notNull(),
  location: varchar("location", { length: 500 }),
  budget: decimal("budget", { precision: 12, scale: 2 }),
  status: projectStatusEnum("status").notNull().default('active'),
  startDate: timestamp("start_date").notNull().defaultNow(),
  endDate: timestamp("end_date"),
  createdBy: varchar("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Project team members (junction table for managers and supervisors)
export const projectTeam = pgTable("project_team", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull().references(() => projects.id, { onDelete: 'cascade' }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  role: text("role").notNull(), // 'project_manager' or 'supervisor'
  assignedAt: timestamp("assigned_at").notNull().defaultNow(),
});

// Employee types table
export const employeeTypes = pgTable("employee_types", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Labourers table
export const labourers = pgTable("labourers", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull().references(() => projects.id),
  employeeTypeId: uuid("employee_type_id").notNull().references(() => employeeTypes.id),
  firstName: varchar("first_name", { length: 100 }).notNull(),
  surname: varchar("surname", { length: 100 }).notNull(),
  idNumber: varchar("id_number", { length: 20 }).notNull(),
  dateOfBirth: timestamp("date_of_birth").notNull(),
  gender: varchar("gender", { length: 20 }).notNull(),
  contactNumber: varchar("contact_number", { length: 20 }).notNull(),
  email: text("email"),
  physicalAddress: text("physical_address"),
  profilePhoto: text("profile_photo").notNull(),
  idDocumentPhoto: text("id_document_photo"),
  bankName: varchar("bank_name", { length: 100 }).notNull(),
  accountNumber: varchar("account_number", { length: 50 }).notNull(),
  accountType: accountTypeEnum("account_type").notNull(),
  branchCode: varchar("branch_code", { length: 20 }).notNull(),
  bankingProofPhoto: text("banking_proof_photo"),
  createdBy: varchar("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Pay rates table
export const payRates = pgTable("pay_rates", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull().references(() => projects.id, { onDelete: 'cascade' }),
  employeeTypeId: uuid("employee_type_id").notNull().references(() => employeeTypes.id),
  rateCategory: rateCategoryEnum("rate_category").notNull(),
  rateAmount: decimal("rate_amount", { precision: 10, scale: 2 }).notNull(),
  unit: rateUnitEnum("unit").notNull(),
  effectiveDate: timestamp("effective_date").notNull().defaultNow(),
  createdBy: varchar("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Work logs table (daily work entries)
export const workLogs = pgTable("work_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull().references(() => projects.id),
  labourerId: uuid("labourer_id").notNull().references(() => labourers.id, { onDelete: 'cascade' }),
  date: timestamp("date").notNull(),
  openMeters: decimal("open_meters", { precision: 10, scale: 2 }).notNull().default('0'),
  closeMeters: decimal("close_meters", { precision: 10, scale: 2 }).notNull().default('0'),
  additionalItems: decimal("additional_items", { precision: 10, scale: 2 }).default('0'),
  totalEarnings: decimal("total_earnings", { precision: 10, scale: 2 }).notNull(),
  recordedBy: varchar("recorded_by").notNull().references(() => users.id),
  recordedAt: timestamp("recorded_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Payment periods table
export const paymentPeriods = pgTable("payment_periods", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull().references(() => projects.id),
  periodStart: timestamp("period_start").notNull(),
  periodEnd: timestamp("period_end").notNull(),
  status: paymentStatusEnum("status").notNull().default('open'),
  totalAmount: decimal("total_amount", { precision: 12, scale: 2 }).notNull().default('0'),
  submittedBy: varchar("submitted_by").references(() => users.id),
  submittedAt: timestamp("submitted_at"),
  approvedBy: varchar("approved_by").references(() => users.id),
  approvedAt: timestamp("approved_at"),
  rejectionReason: text("rejection_reason"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Correction requests table
export const correctionRequests = pgTable("correction_requests", {
  id: uuid("id").primaryKey().defaultRandom(),
  workLogId: uuid("work_log_id").notNull().references(() => workLogs.id),
  requestedBy: varchar("requested_by").notNull().references(() => users.id),
  reason: text("reason").notNull(),
  originalOpenMeters: decimal("original_open_meters", { precision: 10, scale: 2 }),
  originalCloseMeters: decimal("original_close_meters", { precision: 10, scale: 2 }),
  correctedOpenMeters: decimal("corrected_open_meters", { precision: 10, scale: 2 }),
  correctedCloseMeters: decimal("corrected_close_meters", { precision: 10, scale: 2 }),
  status: correctionStatusEnum("status").notNull().default('pending'),
  reviewedBy: varchar("reviewed_by").references(() => users.id),
  reviewedAt: timestamp("reviewed_at"),
  reviewNotes: text("review_notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Audit trail table
export const auditTrail = pgTable("audit_trail", {
  id: uuid("id").primaryKey().defaultRandom(),
  entityType: varchar("entity_type", { length: 50 }).notNull(), // 'work_log', 'payment', 'correction', etc.
  entityId: uuid("entity_id").notNull(),
  action: varchar("action", { length: 50 }).notNull(), // 'created', 'updated', 'approved', 'rejected'
  performedBy: varchar("performed_by").notNull().references(() => users.id),
  changes: text("changes"), // JSON string of changes
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

// Notifications table
export const notifications = pgTable("notifications", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  type: varchar("type", { length: 50 }).notNull(), // 'work_logged', 'payment_approved', etc.
  isRead: boolean("is_read").notNull().default(false),
  relatedEntityType: varchar("related_entity_type", { length: 50 }),
  relatedEntityId: uuid("related_entity_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ createdAt: true, updatedAt: true });
export const upsertUserSchema = createInsertSchema(users).omit({ createdAt: true, updatedAt: true });
export const insertProjectSchema = createInsertSchema(projects).omit({ id: true, createdAt: true, updatedAt: true });
export const insertProjectTeamSchema = createInsertSchema(projectTeam).omit({ id: true, assignedAt: true });
export const insertEmployeeTypeSchema = createInsertSchema(employeeTypes).omit({ id: true, createdAt: true });
export const insertLabourerSchema = createInsertSchema(labourers).omit({ id: true, createdAt: true, updatedAt: true });
export const insertPayRateSchema = createInsertSchema(payRates).omit({ id: true, createdAt: true });
export const insertWorkLogSchema = createInsertSchema(workLogs).omit({ id: true, recordedAt: true, updatedAt: true });
export const insertPaymentPeriodSchema = createInsertSchema(paymentPeriods).omit({ id: true, createdAt: true });
export const insertCorrectionRequestSchema = createInsertSchema(correctionRequests).omit({ id: true, createdAt: true });
export const insertAuditTrailSchema = createInsertSchema(auditTrail).omit({ id: true, timestamp: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, createdAt: true });

// Select types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpsertUser = z.infer<typeof upsertUserSchema>;
export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type ProjectTeam = typeof projectTeam.$inferSelect;
export type InsertProjectTeam = z.infer<typeof insertProjectTeamSchema>;
export type EmployeeType = typeof employeeTypes.$inferSelect;
export type InsertEmployeeType = z.infer<typeof insertEmployeeTypeSchema>;
export type Labourer = typeof labourers.$inferSelect;
export type InsertLabourer = z.infer<typeof insertLabourerSchema>;
export type PayRate = typeof payRates.$inferSelect;
export type InsertPayRate = z.infer<typeof insertPayRateSchema>;
export type WorkLog = typeof workLogs.$inferSelect;
export type InsertWorkLog = z.infer<typeof insertWorkLogSchema>;
export type PaymentPeriod = typeof paymentPeriods.$inferSelect;
export type InsertPaymentPeriod = z.infer<typeof insertPaymentPeriodSchema>;
export type CorrectionRequest = typeof correctionRequests.$inferSelect;
export type InsertCorrectionRequest = z.infer<typeof insertCorrectionRequestSchema>;
export type AuditTrail = typeof auditTrail.$inferSelect;
export type InsertAuditTrail = z.infer<typeof insertAuditTrailSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
